<?php
return [
    'adminEmail' => 'support@8thwonderpromos.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'is_active' => ['0' => 'No','1' => 'Yes'],
    'boolean' => ['1' => 'Yes','0' => 'No'],
    'offers' => ['monthly' => '10','quaterly' => '15', 'halfyearly' => '20', 'yearly' => '30', 'no subscription' => '0'],
    'sandbox_url' => 'https://api.sandbox.paypal.com',
    'paypal_url' => 'https://api.paypal.com',
    'sandbox_paypal_clientId' => 'Aa59mhDWax3KqdDOmPtnUZ5avPCB8O4PVx6kU-oLkObjnUh9Jx_qySICwdnC',
    'sandbox_paypal_clientSecret' => 'ENm6rxBC66lxGf9zi8QaiFSBuVh7Zf18qLZqafA1MFBGTVKWbmHM7xd_5PJR',
    'paypal_clientId' => 'AZu73rXE20fuG93dnwrfGmB-u1IKIIzCYug8m4_Ii10eaw4-21n7dKe-RGd3GabRjQ4sbbcmIshVkgKv',
    'paypal_clientSecret' => 'EAaLd8PSNYacLxgBXU9b0ah-N4fkzBZv867OnsEnF6k1KTBogOzOh0S9-kVg-8JxTf75VChoMvtlsJl6'
];
